# NdurePlan

Training planner and diary. Static site (no build step) on Vercel, data in Supabase.

## Deploy

The database is ready: the migration in `supabase/migrations/` was applied to the live project on 8 Oct 2026.
Push or deploy `app/` to Vercel as before. There's no build step; Vercel serves `public/`.
`.vercelignore` keeps `tests/` and the Strava endpoints in `api/` out of the deployment.

For a fresh Supabase project: paste `supabase/migrations/20261007_planner_diary.sql` into the SQL editor and Run.

## Layout

```
public/
  index.html, login.html, dashboard.html
  css/app.css              all styles (light + dark), no framework
  supabase_api.js          every database call (Supabase client + RLS)
  sports.js                sports, session types, default zones
  js/model.js              pure logic: durations, load, week totals, flags, copy week
  js/state.js              app state + actions (optimistic save, undo, debounced diary)
  js/templates.js          built-in session templates
  js/main.js               wiring, rendering, events
  js/ui/                   week, day (plan/diary), editor, settings, overlay, toast
supabase/migrations/       SQL to run in Supabase
tests/                     unit, end-to-end and real-database tests
api/                       Strava endpoints (not used by the app right now)
```

## How things are counted

- Block times are stored in seconds (`duration_s`). Old blocks with whole minutes (`time_min`) still read correctly.
- Load per minute: Easy 1, AP1 2, AP2 3, AP3 4, Sprint 4. Strength: minutes x RPE / 2.5.
- A session counts as hard with 3+ minutes of AP2, AP3 or sprint work.
- Done load uses the diary time when filled in; strength uses the diary RPE.

## Tests

```
npm test                          # model + data layer (Node 20+)
python3 tests/e2e/flows.py        # phone + desktop flows with a mock database (pip install playwright)
tests/realstack/realstack.py      # real supabase-js against a local Postgres with the migration (needs Postgres 16 on :54329)
```

## Strava

Switched off for now: the app doesn't call it, and `.vercelignore` keeps `api/` out of the deployment.
To bring the endpoints back, delete the `api/` line in `.vercelignore`.
